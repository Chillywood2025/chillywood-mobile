# Chi'lly Chat v4 internal delivery and physical qualification

Date: 2026-09-29 (America/Chicago)

## Verdict

The reviewed v4 source, the two approved database migrations, Android build 95, and iOS build 30 were delivered through their approved internal paths and installed on the designated physical devices. Both devices cold-launched twice and were left with no active call, their test accounts/data preserved, and microphone/camera permissions restored.

The candidate is **not physically qualified for release**. The fresh 105-row matrix is fully dispositioned, but it contains 18 failed rows, one automation-blocked row, and 60 dependency-blocked rows. Twenty-six rows passed. No row remains `NOT RUN`; blocked rows were evaluated and assigned their exact unmet prerequisite rather than being counted as execution or success.

No product repair, OTA publication, public distribution, provider rollout, unrelated database change, entitlement/money operation, or interaction with unrelated users occurred during this delivery task.

## Exact source and validation

- Protected merge: `f44437c8acf9c9ad0f1621c985b3a70831e8459c`
- Tree: `1ed514c1c377cad857eea5a33dabb89de6a78390`
- Reviewed PR head: `1154f786732e73f9c29cae4801095ecaaf8e556d`
- Required Validation run: `36524520873`; every lane selected for PR #537 passed.
- Protected publisher run: `36525112606`; succeeded under Integration 4707730.
- The protected merge has the reviewed PR head's exact tree; CI was not misrepresented as a separate merge-SHA execution.
- Release-review gate: PASS with no open sentinel finding.

## Approved database deployment

Supabase project identity `bmkkhihfbmsnnmcqkoly` was verified. Supabase CLI 2.109.1 listed and deployed only the approved files, in order:

| Version | Exact source SHA-256 | Result |
| --- | --- | --- |
| `20260928164743` | `15ec276cab2c6d3cec66953473e60c69fcd8e2e6d40fc3d082c13f3e4b80a513` | Deployed and exact-body verified |
| `20260929004448` | `26358f49a2e2c850590acde4fa31dddd7de6823aa7a2be722a43def280552c7d` | Deployed and exact-body verified |

Post-deployment readback verified migration history, catalog bodies, owners, ACLs, column privileges, triggers, RLS, CDC absence, and the intended private state-hint/terminal semantics. No historical migration replay, repair operation, seed, public CDC addition, provider rollout, or money-domain change was performed. The current persisted invite sample remained `legacy_webrtc`; the observed ringing deadline was 90 seconds.

## Signed internal delivery

### Android

- EAS build: `a8d91973-2234-49be-be90-0b0d725c7f68`
- Native build: 95
- Runtime/channel: `1.0.0-android-production-v4` / `android-internal-v2`
- AAB SHA-256: `893e7959dbb5d2732b4d20326ac4b9f71c0f00b3c6264351e382f7f6b89ed749`
- Google Play internal submission: `85412a69-a56c-4fe9-b26e-3caf857ef55b` — completed
- Installed through Google Play (`com.android.vending`)
- Installed APK SHA-256: `0609e1b82c6ddc8da7a39857e42ef13976955c69e4a6f7a0b2e4a610f8202c0a`
- APK v2/v3 signatures, Google Play signer, SourceStamp, application identity, v4 runtime/channel, embedded source, and native sender code were verified.
- Two stable cold launches completed without an observed fatal/ANR marker.

### iOS

- EAS build: `3efd0f73-950a-4801-8c97-69e094199e87`
- Native build: 30
- Runtime/channel: `1.0.0-ios-production-v4` / `ios-internal-v2`
- IPA SHA-256: `60c630817af47b85d44b66e2f9e36460451338b3fe812ed9c4c5117c9182cbac`
- EAS submission: `cb7e338d-aa6e-46d9-9b89-eaa1950213d2`
- Apple/TestFlight build identity: `facc0b89-c840-4c5b-8338-a2424de7593f`
- Apple processing state: VALID; internal group `Chillywood Internal`; `IN_BETA_TESTING`; internal only.
- TestFlight installed build 30; v4 runtime/channel and required native-call capability retained.
- Two stable cold launches completed with the process live after each launch.

No duplicate iOS submission, external TestFlight group, public/store release, native rebuild beyond the approved initial pair, or OTA was created.

## Physical matrix totals

The authoritative per-row record is `matrix-results.tsv`.

| Status | Rows |
| --- | ---: |
| PASS | 26 |
| FAIL | 18 |
| AUTOMATION BLOCKED | 1 |
| DEPENDENCY BLOCKED | 60 |
| NOT RUN | 0 |
| Total | 105 |

Seventy-eight rows had at least one physical attempt, totaling 85 attempts. Historical results were not copied forward. The 104 committed IDs plus the separate D5 native-Answer handoff row are all present.

Useful positive evidence includes all four cancel cases, all four 90-second expiry/late-action cases, three of four decline cases, five repeated-End cases, both Android permission-denial/Settings-recovery cases, all eight bidirectional messaging-continuity cases, two-device call transport in both directions, cleanup to idle, and fresh-call/replacement transport in reachable cases. Real audible speech and unmistakable moving video were not asserted where no consenting on-site observer was available.

## Distinct reproduced product defects

### D1 — iPhone microphone recovery is unreliable (P1)

- F01/MC04: on an Android→iPhone video call, the first iPhone mute projected to Android, but unmute failed closed and required leaving the call.
- PM02: after iOS Settings microphone permission was restored, the supported Unmute action became disabled again and the iPhone remained muted.
- MC02: in a separate iPhone voice control sequence, one recovery succeeded, but the call left active state during later healthy cycles before explicit End.
- Expected: authorized microphone capture returns after each supported unmute/Settings recovery without silently losing the call.
- Actual: recovery failed closed or the working call terminated during repeated healthy controls.

### D2 — camera state/publication and lens flip are inconsistent (P1)

- CM01/CM03: Camera Off changed the sender's local state, but the peer continued to show `Cam On`/`Video connected` and retained the remote tile.
- CM02/CM04/F03: Flip Camera on either platform changed the peer tile to black; camera off/on did not restore it while UI labels remained connected/on.
- Expected: peer projection and actual received media follow camera off/on; lens flip preserves or restores unmistakable moving video.
- Actual: peer state stayed stale and lens flip left black rendering.

### D3 — iPhone same-thread voice Answer can be a no-op (P1)

- BL01: two visible Answer attempts on an incoming Android→iPhone voice invite left the iPhone on Answer/Decline and Android Ringing until the authoritative 90-second expiry.
- Expected: Answer performs server acceptance, native/JS handoff, and transport connection.
- Actual: neither endpoint progressed despite the accepted UI actions.

### D4 — iPhone-originated voice invite creation intermittently fails before persistence (P1)

- DE03: two attempts reported that the receiver invite could not be saved and notification was not sent; Android never received an incoming UI.
- A later independent expiry setup did persist a voice invite, so the original failures remain intermittent and are not erased by the later success.

### D5 — background/terminated iPhone video incoming presentation is absent (P1)

- BL07: while iPhone was backgrounded, Android reported push sent/ringing, but no native incoming UI appeared within the observation window.
- BL08: with the app terminated, no native incoming UI appeared at 5 or 15 seconds.
- Expected: supported background/terminated incoming presentation appears within five seconds and offers Answer.
- Actual: presentation and therefore Answer/media were unreachable.

### D6 — iPhone native preparation/handoff is unstable (P1)

- EN01/EN02 setup: app-wide Answer returned `Still preparing this call`; no native alert appeared within 14 seconds and the caller cleared.
- EN04 setup: in-thread video Answer reported it could not hand the call to iPhone while Android stayed ringing.
- A separate D5 attempt did complete native handoff, open the correct thread, connect transport, and clean up; actual audible media remained unmeasured. This later success does not erase the two distinct preparation/handoff failures.

### D7 — Android background voice Answer does not start microphone automatically (P2)

- BL11/F07/RB01/RB03: notification Answer connected transport but Android reported microphone-start failure and opened muted. A supported manual Unmute recovered after foreground return.
- The UI was truthfully fail-closed, but the expected authorized initial microphone capture was unavailable.

### D8 — iOS camera revocation exposes prolonged peer-loss recovery state (P2 / investigate)

- Revoking iOS camera permission during a call caused the OS to terminate the app. Android dropped to one participant and remained `Connecting` beyond the 15-second heartbeat. Restoring permission, relaunching, and reopening the thread rejoined the iPhone and returned both endpoints to Connected.
- Confirmed observation: OS termination/rejoin recovery works eventually. Suspected product issue: peer-loss labeling/recovery remains ambiguous beyond the documented heartbeat.

## Blocked proof and exact prerequisites

- Actual two-way audible speech and unmistakable moving remote video: requires a consenting on-site human observer or a legitimate audio/motion proof method. Status labels/static frames were not promoted to media proof.
- BL03: the system-owned compact CallKit Answer control appeared but remained non-actionable through the trusted Appium session.
- Lock/unlock cases: require the account owner physically present to unlock; no passcode was requested, stored, or automated.
- Bluetooth cases: require the intended physical Bluetooth accessory.
- Account replacement: requires a third authorized identity; the available simulator was not a valid full-app candidate.
- Same-membership reuse: not reachable without forbidden backend manipulation.
- LiveKit rows: no existing authorized canary/account configuration selected LiveKit; provider rollout was not changed.
- Precise pending native-operation races: not faithfully inducible without source/provider manipulation; mounted deterministic tests remain separate evidence.
- Android legacy app-owned speaker controls AR01/AR03 remain unsupported and were not invented.
- Reset Password visual smoke remained blocked by the unavailable recovery mailbox; no token was fabricated.

## Historical evidence reconciliation

- Original PR #535 archive preserved, SHA-256 `2ccfdbcb565a3ad64d224431d5a5b001ce6bf6010d9717c7a41e3ec556e03ea0`.
- All four E01 cited original files were recovered byte-for-byte with provenance; recovery archive SHA-256 `590215d60881d92ecb2e6dea14a63164f70e7a85aec2cf09106cb54a8eb3d22a`.
- Historical PR #535 verdicts remain historical and were not treated as v4 results.

## Final state and next actions

- Both designated devices run the approved v4 internal binaries and are left signed in to their existing consenting test accounts.
- Both are at `No Active Call`; no capture/session is intentionally left active.
- Android and iOS microphone/camera permissions were restored to allowed.
- No rollback was performed because both candidates cold-launch stably and can be left installed; product failures are isolated in this report.
- The evidence archive integrity verifier checks included bytes/references only; it does not convert blocked assertions into physical proof.

Required next actions are source review and focused fixes for D1–D7, plus a decision on D8. After validated fixes and separately authorized compatible delivery, repeat the failed rows and all rows blocked by those defects. Complete the remaining human/hardware-dependent proof with an on-site consenting observer, physical Bluetooth hardware, and any explicitly authorized additional test identity. Do not call the current candidate globally qualified.
