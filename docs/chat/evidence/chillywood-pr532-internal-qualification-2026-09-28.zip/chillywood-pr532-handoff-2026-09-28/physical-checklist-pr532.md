# PR #532 physical qualification checklist

Final execution statuses are recorded in `matrix-results.tsv` and summarized in
`FINAL_EVIDENCE_REPORT.md`. The `PENDING` tokens below are the immutable planning
snapshot retained to prove the original checklist; they are superseded by the
final result appendix and must not be interpreted as unreported execution state.

Product correction: PR #532 merge `c08e86adfe7a23c3792a7081000e6c95f2f0f810`,
tree `bb8f4cbb9e086378f64bdab94eec46b55ff8d558`.

Delivered candidate after the separately validated runtime/configuration-only
PR #534: merge `442f9c6d1d3ed23a7626474cdecd7cf606d3c1d3`, tree
`bd6833408192d1ea547a7317f764b231dd08a422`.

Android installed candidate: Play internal build 94, runtime
`1.0.0-android-production-v3`, channel `android-internal-v2`.

iOS installed candidate: TestFlight internal build 29, runtime
`1.0.0-ios-production-v3`, channel `ios-internal-v2`.

Status values: PENDING, PASS, FAIL, AUTOMATION BLOCKED, DEPENDENCY BLOCKED, NOT RUN.

## Focused PR #532 sequences

- F01 NOT RUN — cold Android -> iPhone video; three iPhone mic cycles
- F02 NOT RUN — immediate same-thread Android -> iPhone video replacement
- F03 NOT RUN — settled-cleanup Android -> iPhone video replacement
- F04 NOT RUN — cold iPhone -> Android video; three Android mic cycles
- F05 NOT RUN — immediate same-thread iPhone -> Android video replacement
- F06 NOT RUN — settled-cleanup iPhone -> Android video replacement
- F07 NOT RUN — Android background before/during mic recovery; foreground before settle
- F08 NOT RUN — iPhone background before/during mic recovery; foreground before settle

## Baseline incoming-state matrix

- BL01 NOT RUN — Android -> iPhone voice; receiver same thread
- BL02 NOT RUN — Android -> iPhone voice; receiver elsewhere in app
- BL03 NOT RUN — Android -> iPhone voice; receiver backgrounded
- BL04 NOT RUN — Android -> iPhone voice; receiver terminated
- BL05 NOT RUN — Android -> iPhone video; receiver same thread
- BL06 NOT RUN — Android -> iPhone video; receiver elsewhere in app
- BL07 NOT RUN — Android -> iPhone video; receiver backgrounded
- BL08 NOT RUN — Android -> iPhone video; receiver terminated
- BL09 NOT RUN — iPhone -> Android voice; receiver same thread
- BL10 NOT RUN — iPhone -> Android voice; receiver elsewhere in app
- BL11 NOT RUN — iPhone -> Android voice; receiver backgrounded
- BL12 NOT RUN — iPhone -> Android voice; receiver terminated
- BL13 NOT RUN — iPhone -> Android video; receiver same thread
- BL14 NOT RUN — iPhone -> Android video; receiver elsewhere in app
- BL15 NOT RUN — iPhone -> Android video; receiver backgrounded
- BL16 NOT RUN — iPhone -> Android video; receiver terminated

## Terminal behavior

- CA01 NOT RUN — Android -> iPhone voice cancel before answer
- CA02 NOT RUN — Android -> iPhone video cancel before answer
- CA03 NOT RUN — iPhone -> Android voice cancel before answer
- CA04 NOT RUN — iPhone -> Android video cancel before answer
- DE01 NOT RUN — Android -> iPhone voice decline
- DE02 NOT RUN — Android -> iPhone video decline
- DE03 NOT RUN — iPhone -> Android voice decline
- DE04 NOT RUN — iPhone -> Android video decline
- EX01 NOT RUN — Android -> iPhone voice expiry and late Answer
- EX02 NOT RUN — Android -> iPhone video expiry and late Answer
- EX03 NOT RUN — iPhone -> Android voice expiry and late Answer
- EX04 NOT RUN — iPhone -> Android video expiry and late Answer
- EN01 NOT RUN — Android -> iPhone voice; Android End and repeated End
- EN02 NOT RUN — Android -> iPhone voice; iPhone End and repeated End
- EN03 NOT RUN — Android -> iPhone video; Android End and repeated End
- EN04 NOT RUN — Android -> iPhone video; iPhone End and repeated End
- EN05 NOT RUN — iPhone -> Android voice; iPhone End and repeated End
- EN06 NOT RUN — iPhone -> Android voice; Android End and repeated End
- EN07 NOT RUN — iPhone -> Android video; iPhone End and repeated End
- EN08 NOT RUN — iPhone -> Android video; Android End and repeated End

## Media controls and recovery

- MC01 NOT RUN — Android mic cycles in voice call
- MC02 NOT RUN — iPhone mic cycles in voice call
- MC03 NOT RUN — Android mic cycles in video call
- MC04 NOT RUN — iPhone mic cycles in video call
- CM01 NOT RUN — Android camera off/on in Android-originated video
- CM02 NOT RUN — Android camera flip in Android-originated video
- CM03 NOT RUN — iPhone camera off/on in iPhone-originated video
- CM04 NOT RUN — iPhone camera flip in iPhone-originated video
- PR01 NOT RUN — Android absent/returns during voice
- PR02 NOT RUN — iPhone absent/returns during voice
- PR03 NOT RUN — Android absent/returns during video
- PR04 NOT RUN — iPhone absent/returns during video
- BG01 NOT RUN — Android background/resume during voice
- BG02 NOT RUN — iPhone background/resume during voice
- BG03 NOT RUN — Android background/resume during video
- BG04 NOT RUN — iPhone background/resume during video
- LK01 NOT RUN — Android lock/unlock during voice
- LK02 NOT RUN — iPhone lock/unlock during voice
- LK03 NOT RUN — Android lock/unlock during video
- LK04 NOT RUN — iPhone lock/unlock during video
- PM01 NOT RUN — Android microphone denial and Settings recovery
- PM02 NOT RUN — iPhone microphone denial and Settings recovery
- PC01 NOT RUN — Android camera denial and Settings recovery
- PC02 NOT RUN — iPhone camera denial and Settings recovery
- AR01 NOT RUN — Android speaker/earpiece during voice
- AR02 NOT RUN — iPhone speaker/earpiece during voice
- AR03 NOT RUN — Android speaker routing during video
- AR04 NOT RUN — iPhone speaker routing during video
- BT01 NOT RUN — Android available Bluetooth interruption
- BT02 NOT RUN — iPhone available Bluetooth interruption

## Cleanup, replacement, and adjacent messaging

- FI01 NOT RUN — immediate fresh Android -> iPhone voice
- FI02 NOT RUN — immediate fresh Android -> iPhone video
- FI03 NOT RUN — immediate fresh iPhone -> Android voice
- FI04 NOT RUN — immediate fresh iPhone -> Android video
- FS01 NOT RUN — settled fresh Android -> iPhone voice
- FS02 NOT RUN — settled fresh Android -> iPhone video
- FS03 NOT RUN — settled fresh iPhone -> Android voice
- FS04 NOT RUN — settled fresh iPhone -> Android video
- SR01 NOT RUN — Android -> iPhone same-account/same-membership voice replacement
- SR02 NOT RUN — Android -> iPhone same-account/same-membership video replacement
- SR03 NOT RUN — iPhone -> Android same-account/same-membership voice replacement
- SR04 NOT RUN — iPhone -> Android same-account/same-membership video replacement
- AC01 NOT RUN — Android account replacement while voice work settles
- AC02 NOT RUN — Android account replacement while video work settles
- AC03 NOT RUN — iPhone account replacement while voice work settles
- AC04 NOT RUN — iPhone account replacement while video work settles
- MS01 NOT RUN — Android -> iPhone messaging before/after cancel
- MS02 NOT RUN — iPhone -> Android messaging before/after cancel
- MS03 NOT RUN — Android -> iPhone messaging before/after decline
- MS04 NOT RUN — iPhone -> Android messaging before/after decline
- MS05 NOT RUN — Android -> iPhone messaging before/after End
- MS06 NOT RUN — iPhone -> Android messaging before/after End
- MS07 NOT RUN — Android -> iPhone messaging around replacement
- MS08 NOT RUN — iPhone -> Android messaging around replacement
- RB01 NOT RUN — Android background before mic recovery starts
- RB02 NOT RUN — Android background while mic recovery pending
- RB03 NOT RUN — Android foreground before mic recovery settles
- RB04 NOT RUN — iPhone background before mic recovery starts
- RB05 NOT RUN — iPhone background while mic recovery pending
- RB06 NOT RUN — iPhone foreground before mic recovery settles

## Required observations in every applicable call row

- Incoming UI within 5 seconds; record invite-to-notification latency.
- Actual Answer, exactly one Room per endpoint, invite-fixed provider.
- Real two-way audible speech, or explicit dependency block if no legitimate observer/proof method exists.
- Video: moving remote video on both endpoints, not merely a static frame/icon.
- Event-driven projection within 2 seconds; heartbeat fallback within 15 seconds.
- Cleanup within 4 seconds or explicit truthful retryable failure.
- Sanitized private message before and after baseline calls; verify delivery/read and account isolation.
- Exact loaded update/build/runtime/channel remains bound for both endpoints.
