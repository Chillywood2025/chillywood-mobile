# PR #532 Internal Candidate — Sanitized Build Receipts

## Source chain

- Product correction: PR #532 merge `c08e86adfe7a23c3792a7081000e6c95f2f0f810`, tree `bb8f4cbb9e086378f64bdab94eec46b55ff8d558`.
- Required source validation: run `36356675077` on PR #532 head `57500106425c5bc8969128d24b37222d6895de22`.
- Delivery generation: PR #533 merge `809be702cb2f391352bc09fb5370719d44821217`, tree `0373c5f6254777c26c4857bc96f554cfed48457a`.
- Internal tester binding: PR #534 merge `442f9c6d1d3ed23a7626474cdecd7cf606d3c1d3`, tree `bd6833408192d1ea547a7317f764b231dd08a422`.
- PR #534 validated head `7ddc9ffbf1b0bef255b7c3a9c0f318e168ef015c`; Required Validation run `36371161278` succeeded.
- Remote protected main readback at closeout: `442f9c6d1d3ed23a7626474cdecd7cf606d3c1d3`.

PRs #533 and #534 contain only the authorized native/runtime/internal-delivery configuration required to carry PR #532's native changes; no later product correction was included.

## Android internal candidate

- EAS build ID: `654debde-e724-4cfc-8bb7-910d8a431ba5`
- EAS status: `FINISHED`
- EAS source: `442f9c6d1d3ed23a7626474cdecd7cf606d3c1d3`
- Build/version: `94` / `1.0.0`
- Runtime/channel: `1.0.0-android-production-v3` / `android-internal-v2`
- Distribution: Google Play internal testing; submission `35f5e73d-ef5c-428d-8d6f-5fe3ba576a09` finished.
- AAB SHA-256: `038128143afa8b6b8db8c1f93e75bb9d5e416ab6d54d33157c1532b07ab28c00`
- Installed extracted APK SHA-256: `4b71cd607e6b51dca7e37e896a8d1a2acbce013ce53444ba7a7a76d065ecce2b`
- AAB JAR integrity: verified; upload signer is the expected self-signed Android upload certificate and Google Play accepted the artifact.
- Installed APK: v2 and v3 signature verification passed; SourceStamp verification passed; installer is Google Play.
- Installed readback: version code `94`, version name `1.0.0`.
- Activation: embedded v3 bundle; no v3 OTA update ID.
- Cold launches: two stable launches passed.

## iOS internal candidate

- EAS build ID: `5520c488-5e09-4ba0-8a98-510c1e75851d`
- EAS status: `FINISHED`
- EAS source: `442f9c6d1d3ed23a7626474cdecd7cf606d3c1d3`
- Build/version: `29` / `1.0.0`
- Runtime/channel: `1.0.0-ios-production-v3` / `ios-internal-v2`
- Distribution: TestFlight internal group `Chillywood Internal`; submission `5e548e10-5df0-44ce-a57c-f1e9655b4b9d` finished.
- IPA SHA-256: `22136a6bd703bf9858399629ccda80549798d2cd4e89e4432f78b978dd0d192d`
- App identity: `com.chillywood.mobile`; installed build readback `29`, version `1.0.0`.
- Provisioning expiration: July 16, 2027.
- Native call capabilities: `voip`, `audio`, and `remote-notification` background modes retained; TestFlight accepted and the designated iPhone installed the signed binary.
- Local verification note: Apple Root CA was temporarily trusted for the approved offline verification and removed immediately afterward. The retained CMS verification output matches the embedded CodeDirectory byte-for-byte. A later strict local `codesign` run therefore reports the expected untrusted-root condition; TestFlight processing and device installation provide the live Apple acceptance boundary.
- Activation: embedded v3 bundle; no v3 OTA update ID.
- Cold launches: two stable launches passed.

## Native compatibility and rollback

- Android native-input digest: `dba8c0cf8cb6c70453f7edc82a0dc5f38da1bfd99cbcfbbcb2886dc36676e890`
- iOS native-input digest: `3d1f37dc61e79c8fd087c8a9b37a569cadaca4789b0b1427f0b8d73c6ec77925`
- v3 supersedes the incompatible v2 native generation; build 92/build 21 remain historical rollback binaries and cannot carry PR #532 completely by OTA.
- No OTA was published because both new internal binaries embed the exact v3 source. No rollback was performed because capture was stopped and both devices were returned to a safe state.
