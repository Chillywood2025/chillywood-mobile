# Chi'lly Chat PR #532 — Internal Delivery and Physical Qualification

Date: September 28, 2026  
Verdict: **NOT QUALIFIED — reproducible product failures and material physical-proof gaps remain.**

This report records the exact internal candidate, first failures, confirmation attempts, blocked proof, and final device cleanup. It does not claim a global pass and does not include any product repair.

## 1. Exact candidate delivered

| Boundary | Identity |
| --- | --- |
| PR #532 product merge | `c08e86adfe7a23c3792a7081000e6c95f2f0f810` |
| PR #532 product tree | `bb8f4cbb9e086378f64bdab94eec46b55ff8d558` |
| PR #532 validated head | `57500106425c5bc8969128d24b37222d6895de22` |
| PR #532 Required Validation | `36356675077` — successful |
| PR #533 delivery-generation merge | `809be702cb2f391352bc09fb5370719d44821217` |
| PR #534 internal-tester merge | `442f9c6d1d3ed23a7626474cdecd7cf606d3c1d3` |
| Installed candidate tree | `bd6833408192d1ea547a7317f764b231dd08a422` |
| PR #534 Required Validation | `36371161278` — successful |
| Closeout protected-main readback | `442f9c6d1d3ed23a7626474cdecd7cf606d3c1d3` |

PRs #533/#534 are the authorized native/runtime/internal-delivery configuration required by PR #532. No unrelated later product source was silently included.

## 2. Delivery and installed identity

| Platform | Internal distribution | Build | Runtime | Channel | Artifact SHA-256 | Installed/loaded state |
| --- | --- | ---: | --- | --- | --- | --- |
| Android | Google Play internal | 94 / EAS `654debde-e724-4cfc-8bb7-910d8a431ba5` | `1.0.0-android-production-v3` | `android-internal-v2` | `038128143afa8b6b8db8c1f93e75bb9d5e416ab6d54d33157c1532b07ab28c00` | Play-installed build 94; embedded v3 source; two stable cold launches |
| iOS | TestFlight internal, `Chillywood Internal` | 29 / EAS `5520c488-5e09-4ba0-8a98-510c1e75851d` | `1.0.0-ios-production-v3` | `ios-internal-v2` | `22136a6bd703bf9858399629ccda80549798d2cd4e89e4432f78b978dd0d192d` | TestFlight-installed build 29; embedded v3 source; two stable cold launches |

Both binaries were new native v3 candidates because the PR #532 Android and iOS native changes are incompatible with builds 92/21. No OTA publication was necessary after installation, so there is no v3 OTA update/group ID. The loaded bundle is accurately classified as embedded, not downloaded or emergency.

Sanitized build/signing details are in `BUILD_RECEIPTS.md`.

## 3. Live provider readback

The closeout read-only aggregate covered the rolling 24-hour window and retained no user, invite, thread, room, device, token, or message identifiers:

- 60 total invites; all 60 stamped `legacy_webrtc`; 0 stamped `livekit`.
- Every invite had an exact 90-second `expires_at - created_at` interval.
- Public default remains `legacy_webrtc`.
- Canary provider remains `livekit`, canary enabled, emergency stop false, and exactly two canary users enabled.
- The designated accounts therefore exercised `legacy_webrtc`; LiveKit was not qualified by this run.

See `provider-readback-sanitized.json`.

## 4. Matrix totals

The immutable planning checklist contained 104 concrete rows. Final row dispositions are in `matrix-results.tsv`.

| Disposition | Rows |
| --- | ---: |
| PASS | 13 |
| FAIL | 10 |
| AUTOMATION BLOCKED | 2 |
| DEPENDENCY BLOCKED | 32 |
| NOT RUN | 47 |
| **Planned total** | **104** |

Fifty-seven rows received a physical attempt or an explicit device/prerequisite evaluation. A blocked row is not an executed pass. Many two-device baseline rows remain blocked because automation could not establish audible two-way speech or objectively prove moving remote video. The phones displayed remote frames, but a static frame/icon/Connected label is not accepted as that proof.

### Family totals

| Family | Planned | Pass | Fail | Blocked | Not run |
| --- | ---: | ---: | ---: | ---: | ---: |
| Focused PR #532 sequences | 8 | 0 | 2 | 4 | 2 |
| Baseline incoming-state matrix | 16 | 0 | 1 | 11 | 4 |
| Terminal behavior | 20 | 7 | 4 | 0 | 9 |
| Media controls | 8 | 0 | 3 | 1 | 4 |
| Recovery/background/lock | 12 | 1 | 0 | 1 | 10 |
| Permission | 4 | 3 | 0 | 1 | 0 |
| Audio route | 6 | 0 | 0 | 2 | 4 |
| Cleanup/fresh calls | 8 | 0 | 0 | 8 | 0 |
| Replacement | 4 | 0 | 0 | 4 | 0 |
| Account replacement | 4 | 0 | 0 | 0 | 4 |
| Messaging | 8 | 2 | 0 | 2 | 4 |
| Recovery ordering | 6 | 0 | 0 | 0 | 6 |

Platform-specific exercised proof included Android and iOS permission denial/recovery, Android force-stop behavior, iOS terminated CallKit presentation, both-direction foreground/background incoming presentation, both-direction call establishment, and both-direction message delivery. The remaining baseline calls are cross-platform by definition; they are therefore not counted as platform passes when either endpoint proof was missing.

## 5. Confirmed product defects

### D1 — End/cleanup does not complete safely

Severity: P1 qualification blocker  
Provider: `legacy_webrtc`  
Repeatability: repeated on ordinary active calls in both directions

Expected: End stops capture locally, closes transport/native UI, performs durable membership cleanup within four seconds, and leaves both endpoints idle.  
Observed: UI fell to `0 in call` but retained stale call state and displayed `Unable to end this Chi'lly Chat call safely` / cleanup-not-complete retry guidance. Repeated End did not prove durable cleanup. Local capture did stop independently.

Evidence:

- `pr534/ios29-after-retry-end-f01.png`
- `pr534/android94-after-retry-end-f01.xml`
- `run/ios29-mc01-cleanup-failed.png`
- `run/android94-mc01-end.xml`

### D2 — Repeated microphone control can collapse/split an established Room

Severity: P1 qualification blocker  
Provider: `legacy_webrtc`  
Repeatability: reproduced with mic control on each endpoint in opposite-direction video calls

Expected: three mic transitions preserve the current Room, peer, video, requested/actual media agreement, and control authority.  
Observed: iPhone mic cycling collapsed the session to zero; Android mic-off initially projected, then both endpoints fell to one participant/Connecting and remained unrecovered beyond the 15-second heartbeat. Cleanup then failed.

Evidence:

- `pr534/ios29-after-mic-cycle-failure.png`
- `pr534/android94-after-mic-cycle.xml`
- `run/android94-mc01-off1.xml`
- `run/ios29-mc01-t15.json`

### D3 — Camera durable projection remains stale on the peer

Severity: P1 media-truth defect  
Provider: `legacy_webrtc`  
Repeatability: reproduced and confirmed

Expected: Android camera-off projects to the iPhone within two seconds, or by the 15-second fallback.  
Observed: Android showed local `Camera Off`, while iPhone continued showing the Android peer as `Cam On` / `Video connected` beyond 15 seconds and for roughly 51 seconds of observation.

Evidence:

- `run/android94-cm01-off-confirm.xml`
- `run/ios29-cm01-off-confirm.json`

### D4 — Background iPhone delivery is intermittent and can overrun the server deadline

Severity: P1 incoming-call reliability defect  
Provider: `legacy_webrtc`  
Repeatability: one failure and one clean confirmation

Expected: native incoming UI appears within five seconds; unanswered state terminates at the exact 90-second server deadline.  
Observed: one Android-to-background-iPhone voice invite never produced CallKit, while Android remained ringing for approximately 156 seconds. A separate clean retry produced CallKit.

Evidence:

- `run/ios29-na05-incoming.json`
- `run/ios29-na05-incoming3.json`
- `run/android94-na05-expired2.xml`

### D5 — iPhone native Answer handoff can strand one endpoint

Severity: P1 qualification blocker  
Provider: `legacy_webrtc`  
Repeatability: one captured failure

Expected: native Answer transfers into one app Room with two present peers and usable media.  
Observed: native Answer opened the app, but iPhone remained at `1 in call`; Android caller was no longer in active call UI. iPhone End then hit the cleanup failure.

Evidence:

- `run/ios29-na05-active.json`
- `run/ios29-na05-final.json`
- `run/android94-na05-active.xml`

### D6 — Caller cancel can leave orphaned iOS CallKit UI

Severity: P1 intermittent terminal-state defect  
Provider: `legacy_webrtc`  
Repeatability: one failure followed by clean voice/video confirmations

Expected: caller cancel removes the receiver's native incoming UI promptly.  
Observed: Android returned to No Active Call, but iOS still displayed native Decline/Accept and required manual Decline. Later clean confirmations passed; the first failure remains reportable.

Evidence:

- `run/ios29-outside-thread-pre.json`
- `run/ios29-ca01-confirm-late.json`
- `run/ios29-ca02-final.json`

## 6. Confirmed passes and partial observations

- Android native Answer reached both endpoints at `2 in call / Connected`; visible remote frames rendered on both devices.
- Peer disappearance/return reconciled back to two peers within the 15-second fallback window.
- Cancel passed cleanly for Android-to-iPhone video and both iPhone-to-Android media types; the intermittent voice orphan remains a failure.
- iPhone-to-Android voice and video decline cleared both endpoints.
- Nominal unanswered expiry removed late Answer and allowed a later fresh invite.
- iPhone microphone and camera denial produced truthful guidance without unauthorized capture, and Settings recovery restored both permissions.
- Android microphone denial/recovery was truthful and restored. Android camera denial was truthful, but the Settings UI/package-state mismatch is classified as an environment/automation block, not a product pass or product defect.
- Bidirectional sanitized messages were delivered and remained visible after thread reopen/scroll, including after call failures.
- Android force-stop remained stopped and showed no stale call after relaunch, matching platform expectations.

## 7. Automation/environment limitations

- No consenting human/audio-proof mechanism was available to prove audible two-way speech. `Connected`, visual meters, and button state were not substituted.
- The cameras were pointed at largely static ceilings. Screenshot hash changes and visible remote frames did not prove moving remote video.
- Three Android flip commands executed without dropping the Room, but the imagery could not prove that the actual lens changed.
- No paired designated Bluetooth device was available.
- Exact native race/failure ordering and pending-operation replacement scenarios could not be induced safely without source instrumentation; they remain mounted-test or future physical-proof work.
- Android Settings visually selected camera Allow while package permission still read denied. The permission was restored through the authorized device control and reverified; this is recorded as an environment/automation anomaly.

## 8. Final device and release state

- Android: build 94, v3 runtime/channel; Camera and Microphone granted; no active Chi'llywood camera/mic app-op, no active call notification, app left at No Active Call.
- iPhone: build 29, v3 runtime/channel; Camera and Microphone restored enabled; no CallKit UI or active call; app left on Home.
- No uncontrolled capture remained.
- No rollback was required or performed.
- No product source, tests, schema, policy, workflow, release tool, or documentation was changed during physical qualification.
- No correction PR or merge was created.
- No public release, public-channel OTA, store production rollout, production provider configuration/database mutation, entitlement change, purchase, payout, or unrelated-user interaction occurred.

## 9. Required next actions

1. Source-review D1–D6 as grouped defects, preserving the first-failure evidence and the later confirmation history.
2. Produce a focused correction through the normal protected workflow; do not reuse this source-specific delivery authorization for changed source.
3. If native source changes again, create a new compatible native generation rather than publishing to v3 by force.
4. Redeliver the validated candidate and rerun the 104-row matrix from all rows reset to NOT RUN.
5. Add a consenting audible-speech observer and a visibly moving video target; add paired Bluetooth equipment if Bluetooth qualification is required.

The authoritative row-by-row status is `matrix-results.tsv`. The archive manifest authenticates every included file.
