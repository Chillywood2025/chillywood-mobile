# PR #530 physical qualification checklist

Final execution statuses are recorded in `matrix-results.tsv` and summarized in
`FINAL_EVIDENCE_REPORT.md`. The `PENDING` tokens below are the immutable planning
snapshot retained to prove the original checklist; they are superseded by the
final result appendix and must not be interpreted as unreported execution state.

Candidate source: `2d96b5396391b0822cb4e10d6b3509639be117f3`

Status values: PENDING, PASS, FAIL, AUTOMATION BLOCKED, DEPENDENCY BLOCKED, NOT RUN.

## Focused PR #530 sequences

- F01 PENDING — cold Android -> iPhone video; three iPhone mic cycles
- F02 PENDING — immediate same-thread Android -> iPhone video replacement
- F03 PENDING — settled-cleanup Android -> iPhone video replacement
- F04 PENDING — cold iPhone -> Android video; three Android mic cycles
- F05 PENDING — immediate same-thread iPhone -> Android video replacement
- F06 PENDING — settled-cleanup iPhone -> Android video replacement
- F07 PENDING — Android background before/during mic recovery; foreground before settle
- F08 PENDING — iPhone background before/during mic recovery; foreground before settle

## Baseline incoming-state matrix

- BL01 PENDING — Android -> iPhone voice; receiver same thread
- BL02 PENDING — Android -> iPhone voice; receiver elsewhere in app
- BL03 PENDING — Android -> iPhone voice; receiver backgrounded
- BL04 PENDING — Android -> iPhone voice; receiver terminated
- BL05 PENDING — Android -> iPhone video; receiver same thread
- BL06 PENDING — Android -> iPhone video; receiver elsewhere in app
- BL07 PENDING — Android -> iPhone video; receiver backgrounded
- BL08 PENDING — Android -> iPhone video; receiver terminated
- BL09 PENDING — iPhone -> Android voice; receiver same thread
- BL10 PENDING — iPhone -> Android voice; receiver elsewhere in app
- BL11 PENDING — iPhone -> Android voice; receiver backgrounded
- BL12 PENDING — iPhone -> Android voice; receiver terminated
- BL13 PENDING — iPhone -> Android video; receiver same thread
- BL14 PENDING — iPhone -> Android video; receiver elsewhere in app
- BL15 PENDING — iPhone -> Android video; receiver backgrounded
- BL16 PENDING — iPhone -> Android video; receiver terminated

## Terminal behavior

- CA01 PENDING — Android -> iPhone voice cancel before answer
- CA02 PENDING — Android -> iPhone video cancel before answer
- CA03 PENDING — iPhone -> Android voice cancel before answer
- CA04 PENDING — iPhone -> Android video cancel before answer
- DE01 PENDING — Android -> iPhone voice decline
- DE02 PENDING — Android -> iPhone video decline
- DE03 PENDING — iPhone -> Android voice decline
- DE04 PENDING — iPhone -> Android video decline
- EX01 PENDING — Android -> iPhone voice expiry and late Answer
- EX02 PENDING — Android -> iPhone video expiry and late Answer
- EX03 PENDING — iPhone -> Android voice expiry and late Answer
- EX04 PENDING — iPhone -> Android video expiry and late Answer
- EN01 PENDING — Android -> iPhone voice; Android End and repeated End
- EN02 PENDING — Android -> iPhone voice; iPhone End and repeated End
- EN03 PENDING — Android -> iPhone video; Android End and repeated End
- EN04 PENDING — Android -> iPhone video; iPhone End and repeated End
- EN05 PENDING — iPhone -> Android voice; iPhone End and repeated End
- EN06 PENDING — iPhone -> Android voice; Android End and repeated End
- EN07 PENDING — iPhone -> Android video; iPhone End and repeated End
- EN08 PENDING — iPhone -> Android video; Android End and repeated End

## Media controls and recovery

- MC01 PENDING — Android mic cycles in voice call
- MC02 PENDING — iPhone mic cycles in voice call
- MC03 PENDING — Android mic cycles in video call
- MC04 PENDING — iPhone mic cycles in video call
- CM01 PENDING — Android camera off/on in Android-originated video
- CM02 PENDING — Android camera flip in Android-originated video
- CM03 PENDING — iPhone camera off/on in iPhone-originated video
- CM04 PENDING — iPhone camera flip in iPhone-originated video
- PR01 PENDING — Android absent/returns during voice
- PR02 PENDING — iPhone absent/returns during voice
- PR03 PENDING — Android absent/returns during video
- PR04 PENDING — iPhone absent/returns during video
- BG01 PENDING — Android background/resume during voice
- BG02 PENDING — iPhone background/resume during voice
- BG03 PENDING — Android background/resume during video
- BG04 PENDING — iPhone background/resume during video
- LK01 PENDING — Android lock/unlock during voice
- LK02 PENDING — iPhone lock/unlock during voice
- LK03 PENDING — Android lock/unlock during video
- LK04 PENDING — iPhone lock/unlock during video
- PM01 PENDING — Android microphone denial and Settings recovery
- PM02 PENDING — iPhone microphone denial and Settings recovery
- PC01 PENDING — Android camera denial and Settings recovery
- PC02 PENDING — iPhone camera denial and Settings recovery
- AR01 PENDING — Android speaker/earpiece during voice
- AR02 PENDING — iPhone speaker/earpiece during voice
- AR03 PENDING — Android speaker routing during video
- AR04 PENDING — iPhone speaker routing during video
- BT01 PENDING — Android available Bluetooth interruption
- BT02 PENDING — iPhone available Bluetooth interruption

## Cleanup, replacement, and adjacent messaging

- FI01 PENDING — immediate fresh Android -> iPhone voice
- FI02 PENDING — immediate fresh Android -> iPhone video
- FI03 PENDING — immediate fresh iPhone -> Android voice
- FI04 PENDING — immediate fresh iPhone -> Android video
- FS01 PENDING — settled fresh Android -> iPhone voice
- FS02 PENDING — settled fresh Android -> iPhone video
- FS03 PENDING — settled fresh iPhone -> Android voice
- FS04 PENDING — settled fresh iPhone -> Android video
- SR01 PENDING — Android -> iPhone same-account/same-membership voice replacement
- SR02 PENDING — Android -> iPhone same-account/same-membership video replacement
- SR03 PENDING — iPhone -> Android same-account/same-membership voice replacement
- SR04 PENDING — iPhone -> Android same-account/same-membership video replacement
- AC01 PENDING — Android account replacement while voice work settles
- AC02 PENDING — Android account replacement while video work settles
- AC03 PENDING — iPhone account replacement while voice work settles
- AC04 PENDING — iPhone account replacement while video work settles
- MS01 PENDING — Android -> iPhone messaging before/after cancel
- MS02 PENDING — iPhone -> Android messaging before/after cancel
- MS03 PENDING — Android -> iPhone messaging before/after decline
- MS04 PENDING — iPhone -> Android messaging before/after decline
- MS05 PENDING — Android -> iPhone messaging before/after End
- MS06 PENDING — iPhone -> Android messaging before/after End
- MS07 PENDING — Android -> iPhone messaging around replacement
- MS08 PENDING — iPhone -> Android messaging around replacement
- RB01 PENDING — Android background before mic recovery starts
- RB02 PENDING — Android background while mic recovery pending
- RB03 PENDING — Android foreground before mic recovery settles
- RB04 PENDING — iPhone background before mic recovery starts
- RB05 PENDING — iPhone background while mic recovery pending
- RB06 PENDING — iPhone foreground before mic recovery settles

## Required observations in every applicable call row

- Incoming UI within 5 seconds; record invite-to-notification latency.
- Actual Answer, exactly one Room per endpoint, invite-fixed provider.
- Real two-way audible speech, or explicit dependency block if no legitimate observer/proof method exists.
- Video: moving remote video on both endpoints, not merely a static frame/icon.
- Event-driven projection within 2 seconds; heartbeat fallback within 15 seconds.
- Cleanup within 4 seconds or explicit truthful retryable failure.
- Sanitized private message before and after baseline calls; verify delivery/read and account isolation.
- Exact loaded update/build/runtime/channel remains bound for both endpoints.
