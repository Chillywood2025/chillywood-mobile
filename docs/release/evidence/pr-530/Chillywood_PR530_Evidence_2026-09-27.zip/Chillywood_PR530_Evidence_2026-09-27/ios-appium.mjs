#!/usr/bin/env node
import fs from "node:fs";
import http from "node:http";

const root = "/private/tmp/chillywood-pr530-evidence.Yh2e3I";
const sessionFile = `${root}/ios-session-id`;
const [command, ...args] = process.argv.slice(2);

function request(method, path, body, sessionId = "") {
  return new Promise((resolve, reject) => {
    const payload = body == null ? null : JSON.stringify(body);
    const req = http.request({
      host: "127.0.0.1",
      port: 4723,
      method,
      path: sessionId ? `/session/${sessionId}${path}` : path,
      headers: payload == null ? {} : {
        "content-type": "application/json",
        "content-length": Buffer.byteLength(payload),
      },
      timeout: 120000,
    }, (res) => {
      let data = "";
      res.on("data", (chunk) => data += chunk);
      res.on("end", () => {
        let parsed;
        try { parsed = JSON.parse(data); } catch { parsed = { value: data }; }
        if (res.statusCode >= 400 || parsed?.value?.error) {
          reject(new Error(parsed?.value?.message || `HTTP ${res.statusCode}`));
          return;
        }
        resolve(parsed?.value);
      });
    });
    req.on("timeout", () => req.destroy(new Error("request timeout")));
    req.on("error", reject);
    if (payload != null) req.write(payload);
    req.end();
  });
}

if (command === "create-session") {
  const prior = JSON.parse(fs.readFileSync(args[0], "utf8"));
  const priorCapabilities = prior?.value?.capabilities ?? {};
  const alwaysMatch = { platformName: "iOS" };
  for (const key of [
    "automationName",
    "udid",
    "bundleId",
    "noReset",
    "useNewWDA",
    "updatedWDABundleId",
    "xcodeOrgId",
    "xcodeSigningId",
    "shouldTerminateApp",
    "newCommandTimeout",
    "autoAcceptAlerts",
    "waitForQuiescence",
    "wdaLaunchTimeout",
    "showXcodeLog",
    "platformVersion",
  ]) {
    if (priorCapabilities[key] !== undefined) alwaysMatch[`appium:${key}`] = priorCapabilities[key];
  }
  const value = await request("POST", "/session", { capabilities: { alwaysMatch, firstMatch: [{}] } });
  const sessionId = String(value?.sessionId ?? "").trim();
  if (!sessionId) throw new Error("Appium did not return a session id");
  fs.writeFileSync(sessionFile, sessionId, { mode: 0o600 });
  process.stdout.write("session-ready\n");
  process.exit(0);
}

const sessionId = fs.readFileSync(sessionFile, "utf8").trim();

async function find(using, value) {
  const element = await request("POST", "/element", { using, value }, sessionId);
  return element["element-6066-11e4-a52e-4f735466cecf"] || element.ELEMENT;
}

if (command === "source") {
  fs.writeFileSync(args[0], await request("GET", "/source", null, sessionId), { mode: 0o600 });
} else if (command === "screenshot") {
  fs.writeFileSync(args[0], Buffer.from(await request("GET", "/screenshot", null, sessionId), "base64"), { mode: 0o600 });
} else if (command === "click-a11y") {
  const elementId = await find("accessibility id", args.join(" "));
  await request("POST", `/element/${elementId}/click`, {}, sessionId);
} else if (command === "click-text") {
  const target = args.join(" ");
  const elementId = await find("-ios predicate string", `label == ${JSON.stringify(target)} OR name == ${JSON.stringify(target)}`);
  await request("POST", `/element/${elementId}/click`, {}, sessionId);
} else if (command === "click-contains") {
  const target = args.join(" ");
  const elementId = await find("-ios predicate string", `label CONTAINS ${JSON.stringify(target)} OR name CONTAINS ${JSON.stringify(target)}`);
  await request("POST", `/element/${elementId}/click`, {}, sessionId);
} else if (command === "type-a11y") {
  const [accessibilityId, ...textParts] = args;
  const text = textParts.join(" ");
  const elementId = await find("accessibility id", accessibilityId);
  await request("POST", `/element/${elementId}/click`, {}, sessionId);
  await request("POST", `/element/${elementId}/value`, { text, value: [...text] }, sessionId);
} else if (command === "tap") {
  const [x, y] = args.map(Number);
  await request("POST", "/actions", { actions: [{ type: "pointer", id: "finger", parameters: { pointerType: "touch" }, actions: [{ type: "pointerMove", duration: 0, x, y }, { type: "pointerDown", button: 0 }, { type: "pause", duration: 100 }, { type: "pointerUp", button: 0 }] }] }, sessionId);
} else if (command === "swipe") {
  const [x1, y1, x2, y2] = args.map(Number);
  await request("POST", "/actions", { actions: [{ type: "pointer", id: "finger", parameters: { pointerType: "touch" }, actions: [{ type: "pointerMove", duration: 0, x: x1, y: y1 }, { type: "pointerDown", button: 0 }, { type: "pointerMove", duration: 600, x: x2, y: y2 }, { type: "pointerUp", button: 0 }] }] }, sessionId);
} else if (command === "back") {
  await request("POST", "/back", {}, sessionId);
} else if (command === "hide-keyboard") {
  await request("POST", "/appium/device/hide_keyboard", {}, sessionId);
} else if (command === "activate") {
  await request("POST", "/appium/device/activate_app", { appId: "com.chillywood.mobile" }, sessionId);
} else if (command === "terminate") {
  await request("POST", "/appium/device/terminate_app", { appId: "com.chillywood.mobile" }, sessionId);
} else if (command === "home") {
  await request("POST", "/execute/sync", { script: "mobile: pressButton", args: [{ name: "home" }] }, sessionId);
} else if (command === "deep-link") {
  await request("POST", "/execute/sync", { script: "mobile: deepLink", args: [{ url: args[0], bundleId: "com.chillywood.mobile" }] }, sessionId);
} else if (command === "lock") {
  await request("POST", "/appium/device/lock", {}, sessionId);
} else if (command === "unlock") {
  await request("POST", "/appium/device/unlock", {}, sessionId);
} else if (command === "background") {
  await request("POST", "/appium/app/background", { seconds: Number(args[0] || -1) }, sessionId);
} else if (command === "record-start") {
  await request("POST", "/appium/start_recording_screen", { options: { videoType: "h264", videoQuality: "medium", timeLimit: "30" } }, sessionId);
} else if (command === "record-stop") {
  fs.writeFileSync(args[0], Buffer.from(await request("POST", "/appium/stop_recording_screen", {}, sessionId), "base64"), { mode: 0o600 });
} else if (command === "wait-click") {
  const [target, timeoutText, startText] = args;
  const timeoutMs = Number(timeoutText || 15000);
  const startMs = Number(startText || Date.now());
  const deadline = Date.now() + timeoutMs;
  let lastError = null;
  while (Date.now() < deadline) {
    try {
      const elementId = await find("-ios predicate string", `label == ${JSON.stringify(target)} OR name == ${JSON.stringify(target)}`);
      await request("POST", `/element/${elementId}/click`, {}, sessionId);
      process.stdout.write(`${JSON.stringify({ found: true, clicked: true, observedMs: Date.now() - startMs })}\n`);
      process.exit(0);
    } catch (error) {
      lastError = error;
      await new Promise((resolve) => setTimeout(resolve, 350));
    }
  }
  process.stdout.write(`${JSON.stringify({ found: false, clicked: false, observedMs: Date.now() - startMs, error: lastError?.message?.slice(0, 200) || null })}\n`);
  process.exit(1);
} else {
  throw new Error(`unsupported command: ${command}`);
}

process.stdout.write("ok\n");
