# PR #530 evidence index

- `physical-checklist.md`: planned and executed physical cases.
- `artifact-sha256.txt`: full existing AAB/IPA digests.
- `android-build-list.json`, `ios-build-list.json`: authoritative EAS build readback (private raw evidence; report uses filtered fields).
- `android-binary-receipt.json`, `ios-binary-receipt.json`: refreshed canonical receipts.
- `android-local-verification.json`, `ios-local-verification.json`: source-bound publisher plans.
- `release-review-gate.json`: exact-source review gate.
- `android-before-appinfo*.png/xml`, `ios-before-appinfo*.png/xml`: pre-publication installed rollback identity.
- `android-update-list.json`, `ios-update-list.json`: pre-publication branch readback.
- Case evidence will use the case ID prefix and contain screenshots, XML, timing notes, and sanitized diagnostics.
- `matrix-results.tsv`: exhaustive 104-row result appendix.
- `FINAL_EVIDENCE_REPORT.md`: consolidated delivery, physical results, defects, cleanup, and safety report.
