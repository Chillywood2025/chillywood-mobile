# PR #530 internal OTA and physical qualification report

Date: 2026-09-27 (America/Chicago)

## Outcome

The exact authorized PR #530 merge was published through the canonical publisher to both internal-v2 channels and loaded by the designated Samsung and Lovers's iPhone. Both devices remained on the authorized candidate through the test session. The candidate did **not** pass the complete physical matrix: 14 rows passed, 32 failed, 6 were automation-blocked, and 52 were dependency-blocked. No global PASS or physical closure is claimed.

No application source, tests, dependencies, schema, workflow, release tooling, or repository documentation changed. No PR or merge was created. No native build, store submission, public release, production configuration/database administration, entitlement override, purchase, payout, or unrelated-user interaction occurred.

## Exact source and protected validation

- Protected merge: `2d96b5396391b0822cb4e10d6b3509639be117f3`
- Tree: `63802aa5f2c67b9bed1476252069e81413f061c7`
- PR: `#530`
- Validated PR head: `81ab74a67993b3fc4fe0c67393ca535a690a58b6`
- Source validation workflow: `36330773824` — success
- Required Validation workflow: `36331905508` — success
- Final live `refs/heads/main`: still the exact authorized merge
- Detached delivery checkout: clean; empty Git diff
- Release review gate: PASS, no findings

## Existing signed binaries

### Android

- Device build: 92
- EAS build/artifact: `b88caea9-17e8-4abf-b8c5-837f233a0f7f`
- Artifact SHA-256: `538959defd5cebe4b640d3469b0ba19aae49c912e385efedde18c9bd1cead270`
- Runtime: `1.0.0-android-production-v2`
- Original binary source/tree: `536d931aafa8470d41a7590930f8b19ae15c31c0` / `b793723ce1853223759f61610563030a581922b7`
- EAS status/distribution: FINISHED / STORE
- Android package identity and AAB JAR signature verified. Upload certificate validity is 2026-07 through 2056-07. The self-signed upload certificate/no-timestamp warning was retained and not misreported as a platform-signature failure.
- Receipt: `android-binary-receipt.json`

### iOS

- Device build: 21
- EAS build/artifact: `dca98686-b7cb-490e-9aa4-b69078bbe69c`
- Artifact SHA-256: `8c42429b4918597b098a298693cc3e5f573adff5f6b7091eb2406b9119a23d2f`
- Runtime: `1.0.0-ios-production-v2`
- Original binary source/tree: `c2b77bad9c34e143a9e05a9881c3c2d3df1c5471` / `7fb85aabe7d1c73d2d0e4c7cec19c07544faf47c`
- EAS status/distribution: FINISHED / STORE
- Bundle: `com.chillywood.mobile`; CMS provisioning signature verified; profile/certificate valid through 2027; APS production and background `audio`, `remote-notification`, and `voip` retained; CallKit/PushKit/WebRTC native evidence verified.
- Required native capability: `ios-native-calls` — present
- Local macOS `codesign --verify` reported local trust-chain `CSSMERR_TP_NOT_TRUSTED`; this was retained honestly. Package CMS/profile verification, EAS authoritative readback, and installation were verified separately.
- Receipt: `ios-binary-receipt.json`

Neither binary was rebuilt or replaced. Binary build-source provenance remained distinct from the OTA source.

## Canonical OTA publication and installed uptake

The repository publisher was used platform-by-platform. There was no matching pre-existing publication to reuse.

| Platform | Internal channel/branch | Runtime | Update ID | Group | Created UTC | Canonical plan |
|---|---|---|---|---|---|---|
| Android | `android-internal-v2` | `1.0.0-android-production-v2` | `01a0e3d9-ddb3-7bf0-a949-ee863be858d4` | `71a7f62c-6388-4594-82df-f5e0f1834d9d` | `2026-09-27T17:11:41.235Z` | `9fc99de5dd4ab0ad1825369b84c23f3cc1d53021193b69d2703d18fd7a3e4127` |
| iOS | `ios-internal-v2` | `1.0.0-ios-production-v2` | `01a0e3dc-b375-7dd4-a455-20c1b4ed905c` | `f59440ad-c747-4254-b75b-69c029617c7f` | `2026-09-27T17:14:47.029Z` | `6e14181b4dcba2387e09a1678dd287501031686853ccb11174a07c504e30438e` |

Provider readback bound both publications to the exact merge/tree in their messages and returned the exact platform/runtime/branch. Both were non-rollback-to-embedded updates.

Installed proof:

- Samsung SM-N986U1: build 92, exact Android runtime/channel/update ID, non-embedded and non-emergency. Two stable cold launches passed.
- Lovers's iPhone (iPhone14,3): build 21, exact iOS runtime/channel/update ID, non-embedded and non-emergency; native calls/runtime gate present. Two stable cold launches passed.
- Preverified rollback updates remained available: Android `ANON_UUID_001`; iOS `ANON_UUID_002`.
- No rollback was performed because both devices were returned to a safe idle state with capture stopped and permissions restored. The candidate is not qualified for promotion.

## Matrix totals

Expanded checklist: 104 concrete rows.

| Result | Count |
|---|---:|
| PASS | 14 |
| FAIL | 32 |
| AUTOMATION BLOCKED | 6 |
| DEPENDENCY BLOCKED | 52 |
| NOT RUN | 0 |

Fifty-two rows produced a complete PASS/FAIL/automation outcome. Fifty-two more were blocked before complete proof, although several retain useful partial observations. Every planned row now has an explicit executed or blocked disposition. The exhaustive row-by-row appendix is `matrix-results.tsv`.

Baseline direction summary:

- Android -> iPhone, eight voice/video x receiver-state rows: 0 PASS, 8 FAIL.
- iPhone -> Android, eight rows: 0 PASS, 4 FAIL, 3 DEPENDENCY BLOCKED, 1 AUTOMATION BLOCKED.
- Every baseline requiring real two-way audible speech remained non-PASS because unattended automation provided no legitimate audibility proof. Moving video was physically recorded in both directions for the reachable IPhone -> Android video call.

Family summary:

- Focused #530 sequences: 1 FAIL, 7 DEPENDENCY BLOCKED.
- Cancel: 3 PASS, 1 AUTOMATION BLOCKED.
- Decline: terminal transition succeeded 4/4, but all four rows FAIL the <=5s incoming expectation.
- Expiry/late Answer: 4 FAIL.
- End/repeated End: 1 PASS, 1 FAIL, 6 DEPENDENCY BLOCKED.
- Mic controls: 2 PASS, 1 FAIL, 1 AUTOMATION BLOCKED.
- Camera controls: 2 PASS, 1 FAIL, 1 DEPENDENCY BLOCKED.
- Peer disappearance/return: 1 FAIL, 3 DEPENDENCY BLOCKED.
- Background/resume: 2 PASS, 2 DEPENDENCY BLOCKED.
- Lock/unlock: 1 AUTOMATION BLOCKED, 3 DEPENDENCY BLOCKED.
- Permission recovery: Android microphone PASS; remaining permission rows blocked.
- Audio routing: 1 FAIL, 3 DEPENDENCY BLOCKED; no designated Bluetooth audio hardware was available.
- Fresh-call families: 5 FAIL, 3 DEPENDENCY BLOCKED.
- Replacement/account families: all 8 DEPENDENCY BLOCKED.
- Messaging: 3 PASS, 2 FAIL, 3 DEPENDENCY BLOCKED.
- Precise background/native-recovery race family: all 6 DEPENDENCY BLOCKED because faithful physical ordering could not be induced without source instrumentation.

## Confirmed defects

### D1 — P1: iPhone same-thread Answer cannot hand off current call

- Reproduced: 2/2 cold Android -> iPhone video attempts; also voice.
- Expected: current ringing invite hands to CallKit/accepted session.
- Actual: `Unable to hand this call to iPhone right now...`; Android remained Ringing.
- Timing: first UI 7.917s, confirmation 22.852s.
- Evidence: `F01-confirm-ios.png`, `F01-incoming-timing.json`, `F01-confirm-incoming-timing.json`, `BL01-ios-result.png`.
- Suggested investigation target (not a proven cause): current CallKit descriptor/claim handoff in `app/chat/[threadId].tsx`, `app/_layout.tsx`, and `_lib/iosNativeCalls`.

### D2 — P1: background/terminated incoming presentation missing

- Affected: iPhone backgrounded/terminated for Android-origin voice/video; Android backgrounded/terminated for iPhone-origin video; Android swipe-terminated voice/video.
- Expected: system/native incoming UI within 5s.
- Actual: no actionable incoming UI at 8s or 23s. Swipe-terminated Android process restarted, but no UI/notification appeared.
- Evidence: `BL03-ios-incoming-23s.png`, `BL07-ios-incoming-23s.png`, `BL08-ios-incoming-23s.png`, `BL12-android-incoming.png`, `BL15-android-23s.xml`, `BL16-valid-android-23s.xml`.
- Suggested target: platform notification/native-call dispatch and cold/background claim recovery.

### D3 — P1: iPhone video microphone cannot recover after mute

- Reproduced: first unmute after mute became disabled and settled back to muted; remote Android remained Muted after 15s. Required three cycles could not complete.
- Explicit synchronization errors were shown; they were treated as truthful failure handling, not PASS.
- Evidence: `BL06-ios-mic-recovery-failure.png`, `BL06-android-after-ios-mic-failure.xml`.
- Suggested target: serialized membership/native mic reconciliation in `use-livekit-chat-call-session.ts`.

### D4 — P1: Android camera cannot re-enable in current video call

- Reproduced: camera off succeeded; two normal re-enable taps, including the 15s fallback boundary, left `Camera Off` while both endpoints remained connected.
- Evidence: `CM01-android-off.xml`, `CM01-android-on.xml`, `CM01-android-confirm.xml`, paired iOS remote XML.
- Suggested target: current-session camera publication/reconciliation after disable.

### D5 — P1: disappeared iPhone peer remains falsely Connected on Android

- Reproduced: terminate iPhone during established voice; Android remained `Connected`, `2 in call` after 5s and after 15s; iPhone relaunched with no call.
- Android End then cleared both safely.
- Evidence: `BL09-android-after-ios-bg.xml` and follow-up state files.
- Suggested target: terminal/disconnect ownership callback and participant heartbeat convergence.

### D6 — P1: unanswered expiry UI does not converge

- Reproduced: 4/4 direction/media combinations.
- Expected: expire at 45s and remove Answer.
- Actual: Ringing/incoming UI remained at 50–52+ seconds; late Answer stayed tappable. Authoritative mutation rejected the late answer and returned idle in reverse-direction cases, so no unauthorized call was established.
- Evidence: `EX01-android-late.xml`, `EX02-android-50s.xml`, `EX03-android-52s.xml`, `EX04-android-50s.xml`.
- Suggested target: outgoing/incoming expiry timers and terminal projection in `app/chat/[threadId].tsx`.

### D7 — P1: fresh Android Answer stops transitioning new invites

- Reproduced after expiry family: visible Android Answer accepted taps but left the same incoming invite and caller Ringing; repeated after clean cold restart.
- Evidence: `FS03-android-connected.xml`, `FS03-android-connected2.xml`, `FS03-retry-android-state.xml` and answer-click JSON.
- Suggested target: stale invite/claim cleanup after late-answer/expiry processing. This is an observed correlation, not a proved root cause.

### D8 — P1: iPhone -> Android test message not observed

- Sanitized message was present on iPhone sender but absent on Android at 8s, 15s, and after normal thread reopen. Android -> iPhone comparison delivered.
- Evidence: `MS-final-ios-self.xml`, `MS-final-android-after-i2a.xml`, `MS-final-android-15s.xml`, `MS-final-android-reopen.xml`, `MS-final-ios-after-a2i.xml`.
- Suggested target: Android thread subscription/refresh and directional delivery/read projection.

### D9 — P2: iPhone receiver/speaker control does not change state

- Two normal route-control taps left accessibility state at `Use speaker`; actual native route change was not observed.
- Evidence: `AR02-ios-speaker.xml`, `AR02-ios-receiver.xml`.
- Suggested target: native selection completion and current-owner reconciliation.

### D10 — P2: incoming UI consistently exceeds 5s expectation

- Measured completed observations ranged from 6.015s to 22.852s. Decline cases were 6.535–7.502s; focused/baseline cases were 6.472–8.309s except the 22.852s confirmation.
- Evidence: `*-incoming-timing.json`.

### D11 — P2 intermittent: remote End returned Android to launcher

- IPhone End cleared the call, but Android unexpectedly showed launcher in 1/2 observations; the second observation remained in the thread.
- Evidence: `F04-android-after-end.png`, `BL06-android-after-remote-end.png`.

### D12 — P1 flaky: foreground CallKit Accept path is not stable

- Android -> iPhone video elsewhere connected once through app Answer then native Accept, but the dedicated settled-fresh attempt lost native Accept and did not connect.
- Attempt history is preserved; later success did not erase earlier failure and vice versa.
- Evidence: `BL06-ios-connected.png`, `FS02-ios-after-app-answer.xml`, `FS02-ios-now.xml`.

## Confirmed successful physical observations

- Both exact candidate updates loaded and cold-launched stably twice.
- One iPhone -> Android video call connected with exactly two participants and fixed provider LiveKit.
- Moving remote video was observed and recorded in both directions; static labels were not used as proof.
- Android video mic mute/unmute projected 3/3; Android voice mic projected 3/3.
- Android and iPhone voice background/resume retained the call state.
- Android microphone denial was truthful and safe; Settings restoration plus unmute recovery passed.
- Android repeated End cleared both endpoints within 4s.
- Decline cleared both endpoints in all four direction/media cases (while missing the timing target).
- Android -> iPhone sanitized messaging delivered after call testing.
- Manual cleanup returned both devices to `No Active Call`.

## Blocked proof and automation distinctions

- Real two-way audible speech: DEPENDENCY BLOCKED. No consenting human listener was present and automation cannot establish audibility.
- IPhone privacy denial/recovery: AUTOMATION BLOCKED. The available real-device session had no trustworthy reversible privacy-control mechanism.
- IPhone lock/unlock: AUTOMATION BLOCKED. WDA timed out waiting for lock; the concurrent call ended, so it was not classified as app PASS/FAIL.
- Android background voice selector case: AUTOMATION BLOCKED; incoming existed but the first selector targeted the wrong surface and invite expired before corrected action.
- Bluetooth interruption: DEPENDENCY BLOCKED; no designated connected audio accessory was available.
- Precise native/mutation race ordering: DEPENDENCY BLOCKED, as required; no source instrumentation or provider-state manufacture was used.
- Account replacement: DEPENDENCY BLOCKED; no safe designated alternate credential/session was available. No authentication or account-isolation boundary was bypassed.

## Final cleanup and safety state

- Both devices: `No Active Call`; no retained capture or ringing invite.
- Android camera permission: granted (restored/unchanged).
- Android microphone permission: granted (restored through Settings).
- IPhone privacy permissions: not mutated.
- IPhone audio-route UI remained at its original receiver-intent state (`Use speaker` action visible).
- Accounts, app data, and channels preserved.
- Candidate updates remain installed on their internal-v2 channels.
- No rollback used; preverified rollback identities remain available.
- Repository source remained unchanged and exact; no fix was implemented.

## Evidence index

- Exhaustive matrix: `matrix-results.tsv`
- Publication/provider readback: `android-update-readback.json`, `ios-update-readback.json`
- Binary receipts: `android-binary-receipt.json`, `ios-binary-receipt.json`
- Installed identity screenshots: `android-after-appinfo-diagnostics.png`, `ios-after-appinfo-diagnostics.png`
- Moving-video recordings: `F04-android-sees-ios-motion.mp4`, `F04-ios-sees-android-motion.mp4`
- Source checkout and all raw sanitized case artifacts are retained in this directory.

Final classification: **NOT QUALIFIED — physical matrix has confirmed failures and blocked proof.**
