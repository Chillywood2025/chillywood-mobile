# Sanitization and exclusions

This bundle contains the complete technical evidence set after deterministic privacy sanitization.

Excluded live/private transport material:

- ios-session-id (live Appium session capability)
- ios-devices.json (raw device identifiers)
- android-build-list.json and ios-build-list.json (raw provider payloads containing private artifact transport)
- android-build-readback.json (raw provider artifact payload; canonical binary receipt retained)
- android-update-list.json and ios-update-list.json (broad provider history; exact publication readbacks retained)
- ios-mobileprovision.plist and DER certificate extracts (raw signing-provider payload; verification output and canonical receipt retained)

Sanitization applied to retained text artifacts:

- email addresses replaced with [REDACTED_EMAIL]
- invite, room, thread, and account UUIDs replaced with stable ANON_UUID_* correlations
- URL query strings replaced with [REDACTED_QUERY]
- authorized update IDs, update-group IDs, and signed build IDs preserved for verification

No screenshot or video pixels were altered. They are local evidence from the two designated consenting test devices.
