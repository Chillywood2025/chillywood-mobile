# Exact retained media source recovery

This folder contains source text and edit hunks retained in the media-audit
agent's tool transcript. It is NOT a redesign, reimplementation, or fresh test
run. Nothing has been applied to the shared recovery repository.

Original local commits (currently absent from filesystem):
- SAR/thread fix: f0a66cc31d91f84471768f22e3c91a0d5ef9947b
- HDR conversion: 4faf1e269137f2d6b7d8c68104baf48bcbe51f8d

Original worktree: /workspace/scratch/b54f0bc31372/clip-render-sar-20261102
Original base: 410109670a268895f91bb5ad359eceacab4f3b33

New files are mechanically composed from the retained Add File text and its
subsequent retained patches. Existing-file edits are retained as patch hunks
where the complete original document is unavailable. Original Git object IDs
for new files were not recorded; new recovery hashes establish the recovered
bytes only, not independent equality with the lost commit. See MANIFEST.txt.

Historical evidence only: core/seek/color/health22 test groups passed; final
color3 groups passed; independent review found no blocker. No tests were rerun
during recovery. Historical log files no longer exist in this filesystem.

Verified recovery: before-SAR, after-SAR, and final-HDR core snapshots all match
their independently retained historical Git blob prefixes (see MANIFEST.txt).
The three new HDR files total255 lines; with16 existing-file insertions this
matches the recorded271-insertion HDR commit summary, but is not a substitute
for missing original hashes of those new files.

Dependencies not recovered here: full clip-export-health.mjs, pool/worker/SQL/UI
source, full seek tests/fixtures/benchmark, and original full pipeline/seek docs.
The retained patch contains only our exact changes to health, core tests and
existing docs. Parent/other agents must recover their surrounding source.
Patch paths are repo-relative; no patch in this folder has been applied to the
shared repository. The verified core patch expects blob15c728539, not main's
older renderer blob. New-file snapshots and patches must not be mistaken for
the complete missing pool implementation or a newly validated release.
