# Exact transcript extraction — not reimplementation

Original parent commit: e86ae1c5373f23bb4dde602280ab68e1f9af9f3e
Original parent tree: 8478cb9dfa26a7b2e5ee70647a5ee17b4aff2441

The three control-plane files were extracted from complete source printed in
this agent's visible task transcript plus its exact subsequent patches. Each
matches its independently recorded final pre-interruption SHA256:

- scripts/clip-export-control-plane-cli.mjs:
  c96f7717d64f52a82c57a92fa7bdbf0276426e145b727561ba4be0535a59dcb1
- scripts/lib/clip-export-control-plane.mjs:
  54da359c23a8655eed64ac0845fb43ab56bc6b7f7fbe0735470fe14a5295bb7f
- tests/clip-export-control-plane.test.mjs:
  d2186d7a93dd2d5fef0d5b0e7b3676582b42bc1b6fc91073ffeb01245474c5d5

The complete final pool systemd service was also printed in this transcript at
10:35:14 UTC, before source freeze. It is reproduced verbatim as a separate
artifact. No independent original SHA256 was recorded for that service; its
current digest does not establish original-commit identity.

recovery-verified.patch contains ONLY the three original-hash-verified files.
recovery-service-transcript.patch contains ONLY the complete printed service.
No tests, builds, installations, provider actions or shared-base edits were run.
The original test results are historical evidence, not new recovery validation.

## Complete final text unavailable in this transcript

- scripts/clip-export-worker-cli.mjs
- scripts/lib/clip-export-worker.mjs
- scripts/lib/clip-export-pool.mjs
- scripts/lib/clip-export-worker-resources.mjs
- scripts/lib/clip-export-scale-plan.mjs
- scripts/lib/clip-export-health.mjs (owned by another agent)
- tests/clip-export-pool.test.mjs
- tests/clip-export-worker-resources.test.mjs
- tests/clip-export-scale-plan.test.mjs
- final edits to tests/clip-export-worker.test.mjs
- final complete ops/clip-export-worker/chillywood-clip-export.service
- final complete docs/CLIP_RENDER_POOL_OPERATIONS.md
- final complete docs/CLIP_RENDER_AUTOSCALING_CONTRACT.md

Some exact partial source/documentation excerpts and patches remain in the
visible transcript. They have not been promoted into guessed complete files.
No nonexact reconstruction has been performed.
