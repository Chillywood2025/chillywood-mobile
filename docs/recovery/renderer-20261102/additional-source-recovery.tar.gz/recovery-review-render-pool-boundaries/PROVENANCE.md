# Retained-output recovery only

Recovered 2026-11-02 12:13–12:14 UTC by read-only boundary reviewer from its retained tool-output text, not reimplementation. No original repository or shared base files changed.

- `clip-export-pool.mjs`: complete content read 10:09:54 UTC, with SHA-256 independently recorded at 10:12:15 UTC. Recovered SHA-256 exactly matches `eabe51fab1ef24dbe8a57eac0de8e6b19213233de4c98edf424bd112abaefc4b`. Git blob `08359857a58f1a10b6d27d97b5034a087801288d` also matches parent's retained final pre-disk-fix blob prefix. This does NOT include the later disk fix; preserve as exact pre-disk-fix source.
- `clip-export-worker.retained.patch`: complete worker diff hunks from 10:09:57 UTC tool output, base blob prefix `bb6e012d2`, result blob prefix `3ac3b29d2`. Original worker SHA-256 observed 10:12:15 UTC was `61575ee1977d73bb9058dd217cb37cfdecbae78e55df1586ffb48563a8de62ab`. No base file applied here; reconstructed full-file hash not yet verified. Later edits are not inferred.
- `clip-export-transport.retained.patch`: complete transport diff hunks from same 10:09:57 UTC tool output, base blob prefix `1e9b99a2c`, result blob prefix `77d292418`. No full-file SHA-256 retained. No base file applied here; result blob not yet verified. Later edits are not inferred.

Parent independently confirmed the pool Git blob on 2026-11-02 12:14 UTC as exact pre-`49c33e881` source. Parent retains the later disk-fix patch separately; it was not applied here. `git apply --numstat` successfully parsed both retained patches without applying them.

All other source files remain unavailable in this folder. Tests were NOT rerun during recovery; prior review tests do not qualify later reconstructed source.
